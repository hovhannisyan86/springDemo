package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserRepository userRepository;

    /*Adding user object imediently*/
    @PostMapping("/add")
    public String add(@ModelAttribute User user){
        userRepository.save(user);
        return "redirect:/home";
    }

    /*This is used when we get form fields one by one*/
    /*public String add(@RequestParam("name") String name, @RequestParam("surname") String surname){

        User user = User.builder()
                .name(name)
                .surname(surname)
                .build();
        String errorMessage="";
        if(user.getName().equals("") || user.getName() == null){
            errorMessage +="Name is required <br/>";
        }
        if(user.getSurname().equals("")|| user.getSurname() == null){
            errorMessage += "Surname is required";
        }
        if(errorMessage.equals("")){
            userRepository.save(user);
            System.out.println(user);
            return "redirect:/home";
        }else{
            *//*ERRORMESSAGE WILL BE ADDED TO SESSION FOR DISPLAYING IN HOME PAGE*//*
            System.out.println("Error message here");
            return  "redirect:/home";
        }
    }*/

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") int id){
        userRepository.deleteById(id);
        return "redirect:/home";
    }
}
