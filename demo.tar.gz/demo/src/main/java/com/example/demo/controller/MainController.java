package com.example.demo.controller;

import com.example.demo.model.Book;
import com.example.demo.model.User;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MainController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    BookRepository bookRepository;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/home")
    public String home(ModelMap modelMap) {
        List<User> userList = userRepository.findAll();
        modelMap.addAttribute("users", userList);
        return "home";
    }

    @GetMapping("/book")
    public String book(ModelMap modelMap){
        List<Book> bookList = bookRepository.findAll();
        List<User> userList = userRepository.findAll();
        modelMap.addAttribute("books", bookList);
        modelMap.addAttribute("authors", userList);
        return "book";
    }
}